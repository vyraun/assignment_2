python3 vocab.py --train-src data/train.de-en.de.wmixerprep  --train-tgt data/train.de-en.en.wmixerprep --vocab-type 'bpe' --size 10000 data/vocab.bin 
